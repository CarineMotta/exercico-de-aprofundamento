function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;
    var errorMessage = document.getElementById('error-message');

    if (name === '' || email === '' || message === '') {
        errorMessage.innerText = 'Por favor, preencha todos os campos.';
        return false;
    } else {
        errorMessage.innerText = '';
        return true;
    }
}
