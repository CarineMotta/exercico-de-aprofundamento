document.getElementById('animateButton').addEventListener('click', function() {
    var button = this;
    
    if (button.classList.contains('animated')) {
        button.classList.remove('animated');
        button.classList.add('animated-back');
    } else {
        button.classList.remove('animated-back');
        button.classList.add('animated');
    }
});
