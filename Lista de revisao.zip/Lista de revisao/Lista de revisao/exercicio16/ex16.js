document.addEventListener("DOMContentLoaded", function() {
    loadTasks();
});

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    const taskList = document.getElementById("taskList");
    taskList.innerHTML = "";
    tasks.forEach(function(task, index) {
        const li = document.createElement("li");
        li.textContent = task.name;
        if (task.completed) {
            li.classList.add("completed");
        }

        // Botão para marcar como concluída
        const completeButton = document.createElement("button");
        completeButton.textContent = "Marcar como Concluída";
        completeButton.addEventListener("click", function(event) {
            event.stopPropagation(); // Impede a ativação do evento de clique no li
            toggleTask(index);
        });
        li.appendChild(completeButton);

        // Botão para remover
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remover";
        removeButton.addEventListener("click", function(event) {
            event.stopPropagation(); // Impede a ativação do evento de clique no li
            removeTask(index);
        });
        li.appendChild(removeButton);

        taskList.appendChild(li);
    });
}

function addTask() {
    const taskInput = document.getElementById("taskInput");
    const taskName = taskInput.value.trim();
    if (taskName !== "") {
        const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
        tasks.push({ name: taskName, completed: false });
        localStorage.setItem("tasks", JSON.stringify(tasks));
        taskInput.value = "";
        loadTasks();
    }
}

function toggleTask(index) {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks[index].completed = !tasks[index].completed;
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
}

function removeTask(index) {
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.splice(index, 1);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
}
