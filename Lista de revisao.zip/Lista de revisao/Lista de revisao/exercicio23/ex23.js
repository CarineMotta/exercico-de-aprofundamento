const api = {
    key: "64ed82577ced7f69cb1687f0ce536131",
    base: "https://api.openweathermap.org/data/2.5/",
    lang: "pt_br",
    units: "metric"
}

const cityElement = document.querySelector('.city');
const dateElement = document.querySelector('.date');
const containerImgElement = document.querySelector('.container-img');
const containerTempElement = document.querySelector('.container-temp div');
const tempUnitElement = document.querySelector('.container-temp span');
const weatherElement = document.querySelector('.weather');
const searchInput = document.querySelector('.form-control');
const searchButton = document.querySelector('.btn');
const lowHighElement = document.querySelector('.low-high');

window.addEventListener('load', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(setPosition, showError);
    }
    else {
        alert('Seu navegador não suporta geolocalização');
    }
});

function setPosition(position) {
    const lat = position.coords.latitude;
    const long = position.coords.longitude;
    coordResults(lat, long);
}

function showError(error) {
    alert(`Erro: ${error.message}`);
}

function coordResults(lat, long) {
    fetch(`${api.base}weather?lat=${lat}&lon=${long}&lang=${api.lang}&units=${api.units}&APPID=${api.key}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erro HTTP: status ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            alert(error.message);
        })
        .then(response => {
            displayResults(response);
        });
}

searchButton.addEventListener('click', function () {
    searchResults(searchInput.value);
});

searchInput.addEventListener('keypress', enter);

function enter(event) {
    const key = event.keyCode;
    if (key === 13) {
        searchResults(searchInput.value);
    }
}

function searchResults(city) {
    fetch(`${api.base}weather?q=${city}&lang=${api.lang}&units=${api.units}&APPID=${api.key}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erro HTTP: status ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            alert(error.message);
        })
        .then(response => {
            displayResults(response);
        });
}

function displayResults(weather) {
    cityElement.innerText = `${weather.name}, ${weather.sys.country}`;

    const now = new Date();
    dateElement.innerText = dateBuilder(now);

    const iconName = weather.weather[0].icon;
    containerImgElement.innerHTML = `<img src="./icons/${iconName}.png">`;

    const temperature = Math.round(weather.main.temp);
    containerTempElement.innerHTML = temperature;
    tempUnitElement.innerHTML = '°C';

    const weatherDescription = capitalizeFirstLetter(weather.weather[0].description);
    weatherElement.innerText = weatherDescription;

    lowHighElement.innerText = `${Math.round(weather.main.temp_min)}°C / ${Math.round(weather.main.temp_max)}°C`;
}

function dateBuilder(d) {
    const days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    const months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

    const day = days[d.getDay()]; //getDay: 0-6
    const date = d.getDate();
    const month = months[d.getMonth()];
    const year = d.getFullYear();

    return `${day}, ${date} ${month} ${year}`;
}

containerTempElement.addEventListener('click', changeTemp);

function changeTemp() {
    const tempNumberNow = parseInt(containerTempElement.innerHTML);

    if (tempUnitElement.innerHTML === "°C") {
        const fahrenheit = (tempNumberNow * 9/5) + 32;
        tempUnitElement.innerHTML = "°F";
        containerTempElement.innerHTML = Math.round(fahrenheit);
    } else {
        const celsius = (tempNumberNow - 32) * 5/9}}
