// Função para validar o login
function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

   
    if (username === "user" && password === "password") {
       
        localStorage.setItem("loggedIn", true);
        alert("Seja Bem Vindo!");
        return true;
    } else {
        alert("Login errado Tente Novamente!");
        return false;
    }
}


document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    validateLogin();
});


window.onload = function() {
    var loggedIn = localStorage.getItem("loggedIn");
    if (loggedIn) {
        alert("Seja Bem Vindo");
        
    }
};
