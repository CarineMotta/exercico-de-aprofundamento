const textInput = document.getElementById('textInput');
const wordCount = document.getElementById('wordCount');

textInput.addEventListener('input', () => {
  const text = textInput.value.trim();
  const words = text === '' ? 0 : text.split(/\s+/).length;
  wordCount.textContent = words;
});
