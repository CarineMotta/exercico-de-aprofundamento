document.getElementById('reserveButton').addEventListener('click', function() {
    var date = document.getElementById('datePicker').value;
    var time = document.getElementById('timePicker').value;

    if (date && time) {
        
        document.getElementById('status').innerText = 'Reserva feita para ' + date + ' às ' + time;
    } else {
        document.getElementById('status').innerText = 'Por favor, selecione uma data e hora';
    }
});
