document.getElementById('meuFormulario').addEventListener('submit', function(event) {
    event.preventDefault(); 
    
    Swal.fire({
      icon: 'success',
      title: 'Envio com sucesso!',
      showConfirmButton: false,
      timer: 1500 
    });
  });
  