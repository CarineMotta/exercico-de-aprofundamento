const imageInput = document.getElementById('image-input');
const videoInput = document.getElementById('video-input');
const otherInput = document.getElementById('other-input');

const imagePreview = document.getElementById('image-preview');
const videoPreview = document.getElementById('video-preview');
const otherPreview = document.getElementById('other-preview');

function previewFiles(input, previewArea) {
  previewArea.innerHTML = '';
  const files = input.files;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const reader = new FileReader();

    reader.onload = function(e) {
      if (input === imageInput) {
        const img = document.createElement('img');
        img.src = e.target.result;
        previewArea.appendChild(img);
      } else if (input === videoInput) {
        const video = document.createElement('video');
        video.src = e.target.result;
        video.controls = true;
        previewArea.appendChild(video);
      } else {
        const span = document.createElement('span');
        span.textContent = file.name;
        previewArea.appendChild(span);
      }
    }

    reader.readAsDataURL(file);
  }
}

imageInput.addEventListener('change', function() {
  previewFiles(this, imagePreview);
});

videoInput.addEventListener('change', function() {
  previewFiles(this, videoPreview);
});

otherInput.addEventListener('change', function() {
  previewFiles(this, otherPreview);
});

const uploadForm = document.getElementById('upload-form');
uploadForm.addEventListener('submit', function(event) {
  event.preventDefault();
  const formData = new FormData(this);

});
