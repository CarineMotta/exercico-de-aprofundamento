document.addEventListener('DOMContentLoaded', () => {
    const addRowButton = document.getElementById('addRowButton');
    const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

    addRowButton.addEventListener('click', () => {
        const newRow = dataTable.insertRow();
        const cell1 = newRow.insertCell(0);
        const cell2 = newRow.insertCell(1);
        cell1.textContent = `Dados ${dataTable.rows.length}.1`;
        cell2.textContent = `Dados ${dataTable.rows.length}.2`;
    });
});
