document.getElementById('checkoutForm').addEventListener('submit', function(event) {
    event.preventDefault();
    if (validateForm()) {
        alert('Pago com sucesso!');
        // Aqui você pode adicionar o código para enviar os dados do formulário para o servidor
        // Por exemplo, usando AJAX ou fetch
    }
});

function validateForm() {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const numeroCartao = document.getElementById('numeroCartao').value;
    const dataExpiracao = document.getElementById('dataExpiracao').value;

    let isValid = true;

    if (nome === '') {
        document.getElementById('nomeError').innerText = 'Por favor, preencha o nome.';
        isValid = false;
    } else {
        document.getElementById('nomeError').innerText = '';
    }

    if (email === '') {
        document.getElementById('emailError').innerText = 'Por favor, preencha o email.';
        isValid = false;
    } else {
        document.getElementById('emailError').innerText = '';
    }

    if (numeroCartao === '') {
        document.getElementById('numeroCartaoError').innerText = 'Por favor, preencha o número do cartão.';
        isValid = false;
    } else {
        document.getElementById('numeroCartaoError').innerText = '';
    }

    if (dataExpiracao === '' || !isValidDate(dataExpiracao)) {
        document.getElementById('dataExpiracaoError').innerText = 'Por favor, insira uma data de expiração válida (MM/AA).';
        isValid = false;
    } else {
        document.getElementById('dataExpiracaoError').innerText = '';
    }

    return isValid;
}

function isValidDate(dateString) {
    const regex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
    return regex.test(dateString);
}
