document.addEventListener('DOMContentLoaded', (event) => {
    const items = document.querySelectorAll('#itemList li');

    items.forEach(item => {
        item.addEventListener('click', function() {
            items.forEach(i => i.classList.remove('highlight'));
            this.classList.add('highlight');
        });
    });
});
