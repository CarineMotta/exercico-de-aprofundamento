document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("submit-comment").addEventListener("click", function() {
        var commentInput = document.getElementById("comment").value;
        if(commentInput.trim() !== "") {
            var commentList = document.getElementById("comments-list");
            var newComment = document.createElement("li");
            newComment.textContent = commentInput;
            commentList.appendChild(newComment);
            document.getElementById("comment").value = ""; // Limpa o campo de comentário após adicionar o comentário à lista
        } else {
            alert("Por favor, insira um comentário antes de enviar.");
        }
    });
});
